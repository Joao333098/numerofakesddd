const { 
    Client, 
    GatewayIntentBits, 
    Collection, 
    InteractionType 
} = require("discord.js");
const fs = require('fs');

// Configurações
const config = require("./config.json");

// Importação de Handlers e Bases de Dados
// Certifique-se que estes arquivos existem nestes caminhos exatos
const events = require('./Handler/events');
const ticketHandler = require('./Eventos/SistemaDeHandlers/ticketHandler');
const { General, emoji } = require('./DataBaseJson');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
    ]
});

client.slashCommands = new Collection();
client.commands = new Collection();
client.aliases = new Collection();

// Carregar Comandos e Eventos
// Verifica se o handler de slash existe antes de chamar para evitar crash
try {
    require('./Handler/slash')(client);
} catch (e) {
    console.log(`[AVISO] Handler de Slash Commands não carregado: ${e.message}`);
}
events.run(client);

client.on('interactionCreate', async (interaction) => {
    if (interaction.__processed) return;

    // Lógica de Comandos Slash
    if (interaction.type === InteractionType.ApplicationCommand) {
        const cmd = client.slashCommands.get(interaction.commandName);
        if (!cmd) return interaction.reply({ content: `Erro: Comando não encontrado.`, ephemeral: true });

        interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);
        
        try {
            cmd.run(client, interaction);
        } catch (e) {
            console.error(`Erro ao executar comando ${interaction.commandName}:`, e);
        }
    } 
    
    // Lógica de Botões e Modals
    else if (interaction.isButton() || interaction.isModalSubmit()) {
        
        // IDs do Sistema de Tickets e Vendas (Ignissis)
        const ticketIds = [
            'adquirir', 'aceitar_termos', 'negar_termos', 'menu_comprar', 
            'menu_depositar', 'menu_configuracoes', 'pagina_anterior', 
            'pagina_proxima', 'confirmar_compra', 'cancelar_compra', 'voltar_menu'
        ];

        const modalIds = [
            'modal_sms24h', 'modal_pix', 'modal_mp', 'modal_ticket', 
            'modal_saldo', 'modal_blacklist', 'modal_cargos'
        ];
        
        // Verifica se é uma interação de ticket, SMS ou Depósito
        const isTicketInteraction = ticketIds.includes(interaction.customId) || 
                                   (interaction.customId && interaction.customId.startsWith('sms_')) ||
                                   (interaction.customId && interaction.customId.startsWith('deposito_')) ||
                                   interaction.customId === 'modal_deposito_outro';

        if (isTicketInteraction) {
            interaction.__processed = true;
            try {
                await ticketHandler.run(interaction, client);
            } catch (error) {
                console.error("Erro no Ticket Handler:", error);
                if (!interaction.replied) interaction.reply({ content: "Ocorreu um erro ao processar o ticket.", ephemeral: true });
            }
            return;
        }

        // Lógica de submissão de modals do painel administrativo
        if (interaction.isModalSubmit() && modalIds.includes(interaction.customId)) {
            
            try {
                if (interaction.customId === 'modal_sms24h') {
                    const apiKey = interaction.fields.getTextInputValue('api_key');
                    General.set('sms24h.api_key', apiKey);
                    return interaction.reply({ content: `${emoji.certo} API Key do SMS24H configurada com sucesso!`, ephemeral: true });
                }
                
                if (interaction.customId === 'modal_pix') {
                    const chave = interaction.fields.getTextInputValue('chave_pix');
                    const tipo = interaction.fields.getTextInputValue('tipo_pix');
                    General.set('pix.chave', chave);
                    General.set('pix.tipo', tipo);
                    return interaction.reply({ content: `${emoji.certo} Configurações PIX atualizadas!`, ephemeral: true });
                }

                if (interaction.customId === 'modal_mp') {
                    const token = interaction.fields.getTextInputValue('access_token');
                    General.set('mercadopago.access_token', token);
                    return interaction.reply({ content: `${emoji.certo} Access Token do Mercado Pago configurado!`, ephemeral: true });
                }
            } catch (error) {
                console.error("Erro ao salvar configurações:", error);
                if (!interaction.replied) interaction.reply({ content: "Erro ao salvar configurações no banco de dados.", ephemeral: true });
            }
        }
    }
});

// Tratamento de Erros para evitar que o bot caia (Anti-Crash)
process.on('unhandledRejection', (reason, promise) => {
    console.log(`🚫 Erro Detectado (Unhandled Rejection):`, reason);
});

process.on('uncaughtException', (error, origin) => {
    console.log(`🚫 Erro Detectado (Uncaught Exception):`, error);
});

// Login
client.login(config.token).catch(err => {
    console.error("Erro ao tentar logar o bot. Verifique o Token no config.json.");
    console.error(err);
});
